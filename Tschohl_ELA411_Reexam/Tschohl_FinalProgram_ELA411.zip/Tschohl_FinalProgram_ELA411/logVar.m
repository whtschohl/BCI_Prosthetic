function [vOpen, vClosed]  = logVar(open, closed, ICA, channels)

    for i = 1:size(open, 2) 
        vOpen(i,:) = log(var(open(:,i))');                                                  %get logarithmic varience of open data
        vClosed(i,:) = log(var(closed(:,i))');                                              %get logarithmic varience of closed data
    end
    
    
        
    both = [abs(vOpen),abs(vClosed)];                                                       %concatanate the logarithmic varience of both open and closed data
    figure
    bar(both);                                                                              % plot bar graph comaring the logarithmic varience of both the open and closed data
    if ICA == true
        title('Natural logaritmic variance of each channel averaged over all trials (ICA)')
        xlabel('Channels');
        ylabel('Natural Logaritc Variance')
        legend({'Open','Closed'},'Location','northeast')
    else
        title('Natural logaritmic variance of each channel averaged over all trials')
        xlabel('Channels');
        ylabel('Natural Logaritc Variance')
        legend({'Open','Closed'},'Location','northeast')
        axis([0 channels+1 0 6])
    end

clearvars all;
end