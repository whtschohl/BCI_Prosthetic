function [firstIntervalData, secondIntervalData]  = extractTrials(data, intervalDur, testDur)
    rawTimeFactor = 1000; % timestamp in ms -> s
    dataLen = height(data);
    samplingFreq = floor(dataLen/testDur);
    samplesPerInterval = intervalDur*samplingFreq;
    trials = floor(dataLen/(samplesPerInterval*2));   
%    outLOG = sprintf('trials= %2d         dataLen=%5d         samplingFreq=%5d      samplesPerInterval=%5d', trials, dataLen, samplingFreq, samplesPerInterval);
%    disp(outLOG);


    % removing any EXG Channels
    keep = ["EXGChannel0" "EXGChannel1" "EXGChannel2" "EXGChannel3" "EXGChannel4" "EXGChannel5" "EXGChannel6" "EXGChannel7" "EXGChannel8" "EXGChannel9" "EXGChannel10" "EXGChannel11" "EXGChannel12" "EXGChannel13" "EXGChannel14" "EXGChannel15" "Timestamp"];
    data = data(:,keep);
    data{:,'Timestamp'}=data{:,'Timestamp'}-data{1,'Timestamp'};
    data{:,'Timestamp'}=data{:,'Timestamp'} ./ rawTimeFactor; % timestamp in ms -> s
%     %%% Pseudo
%     for each trial (data for open and closed)
%        calc init row idx for the trial (1 for 1st, 2nd = idx 12s later (6s
%        open, 6s closed)
%        calc starting idx for closed data from
%           initIDX + intervalDur*samplingFreq %
%               where intervalDur*samplingFreq gives the number of rows in
%               that intervalDu
%     %%
firstIntervalData = [];
secondIntervalData = [];


for trialNumber = 0:(trials-1)
   trialIDX = 1 + trialNumber*2*samplesPerInterval; % NB: each trial has 2 intervals (open and closed)
   secondIDX = trialIDX + samplesPerInterval;
%    outLOG = sprintf('Trial#= %2d         firstIDX=%5d         finalIDX=%5d      left=%5d', trialNumber, trialIDX, secondIDX+samplesPerInterval-1, dataLen - (secondIDX+samplesPerInterval));
%    disp(outLOG);
   firstIntervalData = [firstIntervalData; data{(trialIDX+5):(secondIDX-1), :}];
   secondIntervalData = [secondIntervalData; data{secondIDX:(secondIDX+samplesPerInterval-1), :}];
   
end
end