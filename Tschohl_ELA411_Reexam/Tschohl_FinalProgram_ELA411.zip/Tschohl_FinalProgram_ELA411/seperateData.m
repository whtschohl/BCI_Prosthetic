function [testData, trainData] = seperateData(Data, type)
trainSize = (size(Data, 1))*0.7;

trainData = Data(1:trainSize,:);                                                %train 70% of data
testData = Data(trainSize+1:end,:);                                             %test is the last 30% of data
if type == 1
    testPrediction = ones([1 floor(size(testData,1))]);
    testPrediction = testPrediction';
    testData = [testData(1:size(testPrediction,1),:) testPrediction];
    
    trainPrediction = ones([1 floor(size(trainData,1))]);
    trainPrediction = trainPrediction';
    trainData = [trainData(1:size(trainPrediction,1),:) trainPrediction];
else
    if type == 0
        testPrediction = zeros([1 floor(size(testData,1))]);
        testPrediction = testPrediction';
        testData = [testData(1:size(testPrediction,1),:) testPrediction];
    
        trainPrediction = zeros([1 floor(size(trainData,1))]);
        trainPrediction = trainPrediction';
        trainData = [trainData(1:size(trainPrediction,1),:) trainPrediction];
    end
end
    
end