function [firstIntervalData, secondIntervalData]  = getTrials(data, intervalDur, testDur)
    rawTimeFactor = 1000;                                                                               % timestamp in ms -> s
    dataLen = height(data);
    samplingFreq = floor(dataLen/testDur);
    samplesPerInterval = intervalDur*samplingFreq;
    trials = floor(dataLen/(samplesPerInterval*2));   
                                                                                                        % removing any EXG Channels
                                                                                                        % removing "EXGChannel5" "EXGChannel6" because their logarithmic varience is way too high. this means that the channels were obviously not working
    keep = ["EXGChannel0" "EXGChannel1" "EXGChannel2" "EXGChannel3" "EXGChannel4"  "EXGChannel7" "EXGChannel8" "EXGChannel9" "EXGChannel10" "EXGChannel11" "EXGChannel12" "EXGChannel13" "EXGChannel14" "EXGChannel15" "Timestamp"];                                                     
    data = data(:,keep);
    data{:,'Timestamp'}=data{:,'Timestamp'}-data{1,'Timestamp'};
    data{:,'Timestamp'}=data{:,'Timestamp'} ./ rawTimeFactor; % timestamp in ms -> s

firstIntervalData = [];
secondIntervalData = [];


for trialNumber = 0:(trials-1)
   trialIDX = 1 + trialNumber*2*samplesPerInterval;                                                     % NB: each trial has 2 intervals (open and closed)
   secondIDX = trialIDX + samplesPerInterval;
   firstIntervalData = [firstIntervalData; data{trialIDX:(secondIDX-1), :}];
   secondIntervalData = [secondIntervalData; data{secondIDX:(secondIDX+samplesPerInterval-1), :}];
   
end
end