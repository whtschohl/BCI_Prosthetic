%% INFORMATION
% =========================================================================
% CODE BY:              HANS W TSCHOHL
% DATE FINISHED:        21.02.2022
% 
% FUNCTIONS USED:       logVar
%                       getTrials
%                       applyICA
%                       seperateData  
% DESCRIPTION:
% THIS PROGRAM TAKES GIVEN DATA RECODED USING EED ELECTRODES AND STREAMED 
% TO A TEXT FILE AND IDENTIFIES THE INDEPENDENT COMPONENTS. THIS DATA IS OF 
% BRAIN SIGNALS OF A SUBJECT OPENING AND CLOSING THEIR HAND. THE PROGRAM 
% WILL THEN IDENTIFY WHETHER THE SUBJECT IS OPENING OR CLOSING THEIR HAND.
% 
% BACKGROUND:
% THIS PROGRAM WAS WRITEN AS A REEXAMINATION PROJECT FOR THE COURSE ELA411 
% NEUROTECHNOLOGY AT THE MÄLADARLEN UNIVERSITY IN VÄSTERÅS, SWEDEN
% =========================================================================
%%
clear; close all; clc;

%% Get Data
load("bpFilt.mat");                                                                                                     % Import filter
rawFileNames = ["data\OpenBCI-RAW-2021-12-21_20-11-24.txt" 
    "data\OpenBCI-RAW-2021-12-21_20-16-15.txt"
    "data\OpenBCI-RAW-2021-12-21_20-19-23.txt" 
    "data\OpenBCI-RAW-2021-12-21_20-22-41.txt"
    "data\OpenBCI-RAW-2021-12-22_18-29-37.txt" 
    "data\OpenBCI-RAW-2021-12-22_18-32-33.txt"
    "data\OpenBCI-RAW-2021-12-22_18-34-49.txt" 
    "data\OpenBCI-RAW-2021-12-22_18-37-15.txt"
    "data\OpenBCI-RAW-2021-12-21_20-11-24.txt"];                                                                        % get all the file names of the data to train and test the program

intervalDur = 6;                                                                                                        % set the interval duration between opening(relaxing) and closing the hand
testDur = 120;                                                                                                          % set total time duration for one test
 
openData = [];                                                                                                          % create matrix for all data where the hand is open(relaxed)
closedData = [];                                                                                                        % create matrix for all data where the hand is closed
for i=1:length(rawFileNames)
    rawData = readtable(rawFileNames(i));                                                                               % get table of that contains raw data
    [open, closed] = getTrials(rawData,intervalDur, testDur);                                                           % devide each data set into their seperate trials (12s - 6s open, 6s closed)
    openData = [openData;open];                                                                                         % concatanate all open data trials
    closedData = [closedData;closed];                                                                                   % concatanate all closed data trials
end
clear open closed

lenOpenData = size(openData,1);
Data = [openData ; closedData];
%% Filter

for i = 1:size(Data, 2)
    Data(:,i) = filtfilt(bpFilt, Data(:,i));                                                                            % Filter Data
end
for i = 1:size(openData, 2)
    openData(:,i) = filtfilt(bpFilt, openData(:,i));                                                                    % Filter open data
    closedData(:,i) = filtfilt(bpFilt, closedData(:,i));                                                                % Filter closed data
end

Data = filloutliers(Data,'center');                                                                                     % filter out outliers in data
openData = filloutliers(openData,'center');                                                                             % filter out outliers in open data
closedData = filloutliers(closedData,'center');                                                                         % filter out outliers in closed data

%% apply ICA
q=6;                                                                                                                    % reduced number of independet components
openICA = applyICA(openData, q);                                                                                        % apply ICA processing to closed data
closedICA = applyICA(closedData, q);                                                                                    % apply ICA processing to open data
openICA = filloutliers(openICA,'center');                                                                               % filter out outliers for open ICA processed data
closedICA = filloutliers(closedICA,'center');                                                                           % filter out outliers for closed ICA processed data

%% Plot

title("data after filtering")                                                                                           % Plot signals for comparison to ICA
hold on
plot(closedData(:,3),'color', 'b')
plot(openData(:,3),'color', 'g')
xlabel('time (s)')
ylabel('Voltage (microvolts)')
hold off
legend('closed (b)', 'open (g)')

figure                                                                                                                  % Plot signal to compare to the signal before ICA processing
title("data after ICA")
hold on
plot(closedICA(:,6),'color', 'b')
plot(openICA(:,6),'color', 'g')
xlabel('time (s)')
ylabel('Voltage (microvolts)')
hold off
legend('closed (b)', 'open (g)')


%% logarithmic Varience
% log var before ICA
logVar(openData(:,1:14), closedData(:,1:14), false, 14);                                                                % Plot logarithmic varienc of data before ICA

%log var after ICA
logVar(openICA, closedICA, true, q);                                                                                    % Plot logarithmic varienc of data after ICA


%% seperate data

[testOpen,trainOpen] = seperateData(openICA, 1);                                                                        % seperate open data to 70% train data and 30% test data
[testClosed,trainClosed] = seperateData(closedICA, 0);                                                                  % seperate closed data to 70% train data and 30% test data

test = [testOpen;testClosed];                                                                                           % concatanate test data into one matrix
train = [trainOpen;trainClosed];                                                                                        % concatanate train data into one matrix
%% model predictions

Mdl=fitcsvm(train(:,1:end-1), train(:,end), 'Standardize',true,'KernelFunction','rbf');                                 % create svm model of the ICA processed data
% load("Mdl.mat");
predictions = predict(Mdl, test(:,1:end-1));                                                                            % create a varieable of predictions using the svm model and the test data
acc = sum(test(:,end) == predictions)/size(test,1)                                                                      % test accuracy of predictions
