function Data_ICA = applyICA(data,q)
%% PCA                                                                      
[~,Data_PCA,~,~,~,~] = pca(data,'NumComponents',q);                         % PCA is used first to reduce the dimentions of the problem before using ICA to make the ICA an easier problem to solve
                                                                            % the pca function in matlab also does all of the necessary preprocessing for ICA (centering, whitening, etc.) 
%% ICA
mdl = rica(Data_PCA, q);                                                    % create ICA model
mdl = rica(Data_PCA, q,'InitialTransformWeights',mdl.TransformWeights);     % optimise ICA model using the transform weights of the first model as the initial transform weights
Data_ICA = transform(mdl, Data_PCA);                                        % transform weights (essentially S = WX)
clearvars all
end